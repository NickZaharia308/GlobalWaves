# Proiect GlobalWaves  - Etapa 1

## Copyright 2023 Zaharia Nicusor-Alexandru 325CA

## Idea

### Structure

In the src/ folder there are more .java files:
* AddRemoveInPlaylist
* Backward
* Command
* CreatePlaylist
* Episodes
* FollowingPlaylist
* Forward
* GetTop5Songs
* GetTop5Playlists
* Library
* Like
* Load
* Main
* MusicPlayer
* Next
* Playlists
* PlayPause
* Podcasts
* Prev
* PrintOutput
* Repeat
* Search
* Select
* ShowPlaylists
* ShowPreferredSongs
* Shuffle
* Songs
* Status
* SwitchVisibility
* Test
* Users
